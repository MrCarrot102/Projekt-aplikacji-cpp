#ifndef WIDGETFUNCTIONS_H
#define WIDGETFUNCTIONS_H

#include <QTabWidget>

void createWidgetsTab(QTabWidget *tabWidget);



#endif // WIDGETFUNCTIONS_H
